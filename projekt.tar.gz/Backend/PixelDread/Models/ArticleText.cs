﻿namespace PixelDread.Models
{
    public class ArticleText : Article
    {
        public string Content { get; set; } // HTML obsah
    }
}
