﻿namespace PixelDread.Models
{
    public class ArticleLink : Article
    {
        public string Url { get; set; }
        public string ? Placeholder { get; set; }

    }
}
