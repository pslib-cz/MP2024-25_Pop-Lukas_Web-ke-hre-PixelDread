﻿namespace PixelDread.Models
{
    public class ArticleFAQ : Article
    {
        public string Question { get; set; }
        public string Answer { get; set; }
    }
}
