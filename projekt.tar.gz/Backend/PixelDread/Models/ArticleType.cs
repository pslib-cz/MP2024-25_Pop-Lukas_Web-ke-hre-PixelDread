﻿namespace PixelDread.Models
{
    public enum ArticleType
    {
        Text = 1,
        Media = 2,
        Link = 3,
        FAQ = 4
    }

}
