﻿namespace PixelDread.Models
{
    public abstract class Article
    {
        public int Id { get; set; }
        public int PostId { get; set; }

    }
}
